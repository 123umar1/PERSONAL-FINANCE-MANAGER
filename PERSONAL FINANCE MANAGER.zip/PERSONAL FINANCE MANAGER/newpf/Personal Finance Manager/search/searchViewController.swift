//
//  searchViewController.swift
//  Personal Finance Manager
//
//  Created by Umar  on 09/12/2018.
//  Copyright © 2018 Umar . All rights reserved.
//

import UIKit
import SQLite3


class searchViewController: UIViewController , UICollectionViewDataSource, UICollectionViewDelegate , UITableViewDelegate,UITableViewDataSource , UISearchResultsUpdating , UISearchBarDelegate {
    func updateSearchResults(for searchController: UISearchController) {
        
    }
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        filtered_arr = search_arr.filter({$0.sub_type.uppercased().prefix(searchText.count)==searchText.uppercased()})
        flag = true
        tblview.reloadData()
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if flag {
            return filtered_arr.count
        }
        else
        {
            return search_arr.count

        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell : search_customTableViewCell = tblview.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! search_customTableViewCell
        if flag  {
            cell.lbltitle.text = filtered_arr[indexPath.row].sub_type
            cell.lbl_subtitle.text = filtered_arr[indexPath.row].notes
            cell.lbldate.text = filtered_arr[indexPath.row].datee
            cell.lblprice.text = filtered_arr[indexPath.row].amount
        }
       else
        {
            cell.lbltitle.text = search_arr[indexPath.row].sub_type
            cell.lbl_subtitle.text = search_arr[indexPath.row].notes
            cell.lbldate.text = search_arr[indexPath.row].datee
            cell.lblprice.text = search_arr[indexPath.row].amount
        }
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70
    }
    @IBOutlet weak var tblview: UITableView!
    
    @IBOutlet weak var rdbtn: DLRadioButton!
    @IBOutlet weak var menu_collection: UICollectionView!
    var menu = ["HOME","SEARCH","RECORD","CATEGORIES","CHARTS","SETTINGS"]

    var search_arr = [seacrh_cls]()
    var filtered_arr = [seacrh_cls]()
    var dbb: OpaquePointer?
    var flag = false
    @IBOutlet weak var search_bar: UISearchBar!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        prepareDatabaseFile()
        select_Serach_data()
        byprice()
        bydate()
        tblview.reloadData()
     }
    @IBAction func rdbtn(_ sender: DLRadioButton) {
        if sender.tag == 0 {
            search_arr.removeAll()
            bydate()
            self.tblview.reloadData()
            
        }
        if sender.tag == 1 {
            search_arr.removeAll()
            byprice()
            self.tblview.reloadData()

                    }
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return menu.count
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let name = menu[indexPath.row]
        
        if name == "HOME" {
            let secondVC  = storyboard?.instantiateViewController(withIdentifier: "homeViewController") as! HomeViewController
            self.navigationController?.pushViewController(secondVC, animated: true)
        }
        if name == "RECORD" {
            let secondVC  = storyboard?.instantiateViewController(withIdentifier: "recordViewController") as! recordViewController
            self.navigationController?.pushViewController(secondVC, animated: true)
        }
        if name == "CATEGORIES" {
            let secondVC  = storyboard?.instantiateViewController(withIdentifier: "categoryViewController") as! CategoryViewController
            self.navigationController?.pushViewController(secondVC, animated: true)
        }
        
        if name == "CHARTS" {
            let secondVC  = storyboard?.instantiateViewController(withIdentifier: "chartsViewController") as! ChartsViewController
            self.navigationController?.pushViewController(secondVC, animated: true)        }
        if name == "SETTINGS" {
            let secondVC  = storyboard?.instantiateViewController(withIdentifier: "settingsViewController") as! SettingsViewController
            self.navigationController?.pushViewController(secondVC, animated: true)        }
        
        
    }
    
    func select_Serach_data() {
        var queryStatement: OpaquePointer? = nil
        // 1
        let queryStatementString = "select Category_subtype , R_Date, Amount , Notes from Record;"
        if sqlite3_prepare_v2(dbb, queryStatementString, -1, &queryStatement, nil) == SQLITE_OK {
            // 2
            while(sqlite3_step(queryStatement) == SQLITE_ROW){
                
                let top = seacrh_cls()
                let queryResultCol1 = sqlite3_column_text(queryStatement, 0)
                let a = String(cString: queryResultCol1!)
                top.sub_type = a
                
                
                let queryResultCol2 = sqlite3_column_text(queryStatement, 1)
                let b = String(cString: queryResultCol2!)
                top.datee = b
                
                let queryResultCol3 = sqlite3_column_text(queryStatement, 2)
                let c = String(cString: queryResultCol3!)
                top.amount = c
                
                let queryResultCol4 = sqlite3_column_text(queryStatement, 3)
                let d = String(cString: queryResultCol4!)
                top.notes = d
                
                search_arr.append(top)
                
            }
            if sqlite3_step(queryStatement) == SQLITE_ROW {
                
            } else {
                print("Query returned no results")
            }
        } else {
            print("SELECT statement could not be prepared")
        }
        // 6
        sqlite3_finalize(queryStatement)
        
    }
    
    func byprice() {
        var queryStatement: OpaquePointer? = nil
        // 1
        let queryStatementString = "select Category_subtype , R_Date, Amount , Notes from Record order by Amount DESC;"
        if sqlite3_prepare_v2(dbb, queryStatementString, -1, &queryStatement, nil) == SQLITE_OK {
            
            while(sqlite3_step(queryStatement) == SQLITE_ROW){
                
                let top = seacrh_cls()
                let queryResultCol1 = sqlite3_column_text(queryStatement, 0)
                let a = String(cString: queryResultCol1!)
                top.sub_type = a
                
                
                let queryResultCol2 = sqlite3_column_text(queryStatement, 1)
                let b = String(cString: queryResultCol2!)
                top.datee = b
                
                let queryResultCol3 = sqlite3_column_text(queryStatement, 2)
                let c = String(cString: queryResultCol3!)
                top.amount = c
                
                let queryResultCol4 = sqlite3_column_text(queryStatement, 3)
                let d = String(cString: queryResultCol4!)
                top.notes = d
                
                search_arr.append(top)
                
                
            }
            if sqlite3_step(queryStatement) == SQLITE_ROW {
                self.tblview.reloadData()
                
            } else {
                print("Query returned no results")
                
            }
        } else {
            print("SELECT statement could not be prepared")
        }
        // 6
        sqlite3_finalize(queryStatement)

    }
    
    func bydate() {
        var queryStatement: OpaquePointer? = nil
        // 1
        let queryStatementString = "select Category_subtype, R_Date, Amount , Notes from Record order by Date ASC;"
        if sqlite3_prepare_v2(dbb, queryStatementString, -1, &queryStatement, nil) == SQLITE_OK {
            
            while(sqlite3_step(queryStatement) == SQLITE_ROW){
                
                let top = seacrh_cls()
                let queryResultCol1 = sqlite3_column_text(queryStatement, 0)
                let a = String(cString: queryResultCol1!)
                top.sub_type = a
                
                
                let queryResultCol2 = sqlite3_column_text(queryStatement, 1)
                let b = String(cString: queryResultCol2!)
                top.datee = b
                
                let queryResultCol3 = sqlite3_column_text(queryStatement, 2)
                let c = String(cString: queryResultCol3!)
                top.amount = c
                
                let queryResultCol4 = sqlite3_column_text(queryStatement, 3)
                let d = String(cString: queryResultCol4!)
                top.notes = d
                
                search_arr.append(top)
                
            }
            if sqlite3_step(queryStatement) == SQLITE_ROW {
                
                self.tblview.reloadData()
                
            } else {
                print("Query returned no results")
            }
        } else {
            print("SELECT statement could not be prepared")
        }
        // 6
        sqlite3_finalize(queryStatement)
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell : search_customCollectionViewCell = menu_collection.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! search_customCollectionViewCell
        cell.lblname.text = menu[indexPath.row]
        cell.lblname.text = menu[indexPath.row]
        
        if cell.lblname.text == "SEARCH"
        {
            cell.lbl2.isHidden = false
        }
        else
        {
            cell.lbl2.isHidden = true
            
        }
        return cell
    }
    
    func  prepareDatabaseFile()->String
    {
        let fileName: String = "Personal_finance2.db"
        let fileManager:FileManager=FileManager.default
        let directory=fileManager.urls(for: .documentDirectory, in: .userDomainMask).first!
        let documentUrl=directory.appendingPathComponent(fileName)
        // let bundleUrl=Bundle.main.resourceURL?.appendingPathComponent(fileName)
        let bundleUrl=Bundle.main.url(forResource: "Personal_finance2", withExtension: "db")
        //Bundle.main.resourceURL?.appendingPathComponent(fileName)
        
        print(bundleUrl?.path)
        print(documentUrl.path)
        
        if fileManager.fileExists(atPath: (documentUrl.path))
        {
            print("db already exists")
            let _ = openDatabase(path: documentUrl.path)
            return documentUrl.path
        }
            
        else if fileManager.fileExists(atPath: (bundleUrl?.path)!)
        {
            do{
                print("db missing, copying from bundle")
                try fileManager.copyItem(at: bundleUrl!, to: documentUrl)
            }catch{
                print("copy db error")
            }
        }
        return documentUrl.path
    }
    func openDatabase(path:String) -> OpaquePointer? {
        var db: OpaquePointer? = nil
        if sqlite3_open(path, &db) == SQLITE_OK {
            print("Successfully opened connection to database at \(path)")
            self.dbb = db
            //            print(dbb)
            //   select()
            return db
        } else {
            print("Unable to open database. Verify that you created the directory described " +
                "in the Getting Started section.")
            //            PlaygroundPage.current.finishExecution()
            return db
        }
    }
}

class seacrh_cls {
    var sub_type = " "
    var datee = " "
    var notes = ""
    var amount = " "
    init() {
        sub_type = " "
        amount = " "
        datee = ""
        notes = ""
            }
}
