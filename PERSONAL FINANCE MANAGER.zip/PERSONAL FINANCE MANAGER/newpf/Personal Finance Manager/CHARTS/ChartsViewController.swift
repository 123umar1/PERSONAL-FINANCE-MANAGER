//

import UIKit
import CoreCharts
import SQLite3

class ChartsViewController: UIViewController,CoreChartViewDataSource  {
    var dbb: OpaquePointer?
    var record = [income_cls]()
    var inc = String()
    
    
    func didTouch(entryData: CoreChartEntry) {
        print(entryData.barTitle)
    }
    
    func loadCoreChartData() -> [CoreChartEntry] {
        
        return getTurkeyFamouseCityList()
        
    }

    @IBOutlet weak var barChart: VCoreBarChart!
    
    func getTurkeyFamouseCityList()->[CoreChartEntry] {
        var allCityData = [CoreChartEntry]()
        let cityNames = ["Income","Expense"]
        let plateNumber = [34,45]
        
        for index in 0..<cityNames.count {
            
            let newEntry = CoreChartEntry(id: "\(plateNumber[index])", barTitle: cityNames[index], barHeight: Double(plateNumber[index]), barColor: rainbowColor())
            allCityData.append(newEntry)
            
        }
        
        return allCityData
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        barChart.dataSource = self

        // Do any additional setup after loading the view.
    }
    
    func  prepareDatabaseFile()->String
    {
        let fileName: String = "Personal_finance2.db"
        let fileManager:FileManager=FileManager.default
        let directory=fileManager.urls(for: .documentDirectory, in: .userDomainMask).first!
        let documentUrl=directory.appendingPathComponent(fileName)
        // let bundleUrl=Bundle.main.resourceURL?.appendingPathComponent(fileName)
        let bundleUrl=Bundle.main.url(forResource: "Personal_finance2", withExtension: "db")
        //Bundle.main.resourceURL?.appendingPathComponent(fileName)
        
        print(bundleUrl?.path)
        print(documentUrl.path)
        
        if fileManager.fileExists(atPath: (documentUrl.path))
        {
            print("db already exists")
            let _ = openDatabase(path: documentUrl.path)
            return documentUrl.path
        }
            
        else if fileManager.fileExists(atPath: (bundleUrl?.path)!)
        {
            do{
                print("db missing, copying from bundle")
                try fileManager.copyItem(at: bundleUrl!, to: documentUrl)
            }catch{
                print("copy db error")
            }
        }
        return documentUrl.path
    }
    func openDatabase(path:String) -> OpaquePointer? {
        var db: OpaquePointer? = nil
        if sqlite3_open(path, &db) == SQLITE_OK {
            print("Successfully opened connection to database at \(path)")
            self.dbb = db
            //            print(dbb)
            //   select()
            return db
        } else {
            print("Unable to open database. Verify that you created the directory described " +
                "in the Getting Started section.")
            //            PlaygroundPage.current.finishExecution()
            return db
        }
        
    }
    
    
    func select_income() {
        var queryStatement: OpaquePointer? = nil
        // 1
        let queryStatementString = "select Amount(SUM) from Record where Category_type = 'Income' ;"
        if sqlite3_prepare_v2(dbb, queryStatementString, -1, &queryStatement, nil) == SQLITE_OK {
            // 2
            while(sqlite3_step(queryStatement) == SQLITE_ROW){
                let queryResultCol2 = sqlite3_column_text(queryStatement, 1)
                let b = String(cString: queryResultCol2!)
                inc = b
          }
            if sqlite3_step(queryStatement) == SQLITE_ROW {
                
            } else {
                print("Query returned no results")
            }
        } else {
            print("SELECT statement could not be prepared")
        }
        // 6
        sqlite3_finalize(queryStatement)
        
    }


}
