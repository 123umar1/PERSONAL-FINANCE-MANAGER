//
//  CalendarViewController.swift
//  Dairy
//
//  Created by Naqeeb Ahmed on 5/7/18.
//  Copyright © 2018 Ali Apple. All rights reserved.
//

import UIKit
var didselectcaldate = datee()
var selected_date_fornote = " "
var date_for_event_select = " "
class CalendarViewController: UIViewController , UICollectionViewDataSource , UICollectionViewDelegate {
    @IBOutlet weak var selected_date: UILabel!
    @IBOutlet weak var MonthLabel: UILabel!
    @IBOutlet weak var calender: UICollectionView!
     var abc = [datee]()
    
    let Months = ["January","Febrary","March","April","May","June","July","August","September","October","November","December"]
    let DaysOfMonth = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    var DaysInMonth=["31","28","31","30","31","30","31","31","30","31","30","31"]
    var currentMonth=String()
    var NumberOfEmptyBox = Int()
    var NextNumberOfEmptyBox = Int()
    var PriviousNumberOfEmptyBox = 0
    var Direction = 0
    var positionIndex = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        GetStartedDateDayPosition()
        currentMonth = Months[month1]
        MonthLabel.text="\(currentMonth)\(year1)"
        btnnextpressed(UIButton())
        btnprivious(UIButton())
        calender.reloadData()
        // Do any additional setup after loading the view.
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func btnnextpressed(_ sender: Any) {
        switch currentMonth {
        case "December":
            month1 = 0
            year1 += 1
            Direction = 1
            GetStartedDateDayPosition()
            currentMonth = Months[month1]
            MonthLabel.text="\(currentMonth)\(year1)"
            calender.reloadData()
        default:
            
            Direction = 1
            GetStartedDateDayPosition()
            month1 += 1
            currentMonth = Months[month1]
            MonthLabel.text="\(currentMonth)\(year1)"
            calender.reloadData()
        }
    }
    
    @IBAction func btnprivious(_ sender: Any) {
        
        switch currentMonth {
        case "January":
            month1 = 11
            year1 -= 1
            Direction = -1
            GetStartedDateDayPosition()
            currentMonth = Months[month1]
            MonthLabel.text="\(currentMonth)\(year1)"
            calender.reloadData()
        default:
            month1 -= 1
            Direction = -1
            GetStartedDateDayPosition()
            currentMonth = Months[month1]
            MonthLabel.text="\(currentMonth)\(year1)"
            calender.reloadData()
        }
    }
    
    func GetStartedDateDayPosition() {
        switch Direction {
        case 0:
            switch day1 {
            case 1...7:
                NumberOfEmptyBox = weekday1 - day1
                
            case 8...14:
                
                NumberOfEmptyBox = weekday1 - day1 - 7
                
            case 15...21:
                NumberOfEmptyBox = weekday1 - day1 - 14
                
            case 22...28:
                NumberOfEmptyBox = weekday1 - day1 - 21
                
            case 29...31:
                NumberOfEmptyBox = weekday1 - day1 - 28
                
            default:
                break
            }
            positionIndex = NumberOfEmptyBox
            
        case 1...:
            NextNumberOfEmptyBox = ( positionIndex + Int(DaysInMonth[month1])!)%7
            positionIndex = NextNumberOfEmptyBox
            
        case -1:
            PriviousNumberOfEmptyBox = (7 - (Int(DaysInMonth[month1])! - positionIndex )%7 )
            if PriviousNumberOfEmptyBox == 7
            {
                PriviousNumberOfEmptyBox = 0
            }
            
            positionIndex = PriviousNumberOfEmptyBox
        default:
            fatalError()
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        switch Direction {
        case 0:
            return Int(DaysInMonth[month1])! + NumberOfEmptyBox
        case 1...:
            return Int(DaysInMonth[month1])! + NextNumberOfEmptyBox
        case -1:
            return Int(DaysInMonth[month1])! + PriviousNumberOfEmptyBox
            
        default:
            fatalError()
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "calendar", for: indexPath) as! dateCollectionViewCell
        cell.backgroundColor = UIColor.clear
        cell.datelabel.textColor = UIColor.black
        print(date1)
        
        if cell.isHidden
        {
            cell.isHidden=false
            //cell.check.isHidden = false
        }
        
        
        switch Direction {
        case 0:
            cell.datelabel.text = "\(indexPath.row + 1 - NumberOfEmptyBox)"
        case 1...:
            cell.datelabel.text = "\(indexPath.row + 1 - NextNumberOfEmptyBox)"
        case -1:
            cell.datelabel.text = "\(indexPath.row + 1 - PriviousNumberOfEmptyBox)"
        default:
            fatalError()
        }
        
        if Int(cell.datelabel.text!)! < 1
        {
            cell.isHidden = true
        }
        else{
            
            if iseventexist(m: currentMonth, y: year1, d: Int(cell.datelabel.text!)!){
                //cell.check.isHidden = false
            }
            else{
                //cell.check.isHidden = true
            }
        }
        
        switch indexPath.row {
        case 0,6,7,13,14,20,21,27,28,34,35:
            if Int(cell.datelabel.text!)!>1
            {
                cell.datelabel.textColor = UIColor.gray
            }
      
        default:
            break
        }
        print(indexPath.row - 1)
        if currentMonth == Months[calendar.component(.month, from: date1) - 1 ] && year1 == calendar.component(.year, from: date1)  && indexPath.row + 1 == day1
        {
            
            cell.backgroundColor = UIColor.red
            
        }
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        // print(indexPath.row)
        
        
        if let cell = collectionView.cellForItem(at: indexPath) as? dateCollectionViewCell
        {
            var selectdate = "\(cell.datelabel.text!)/\(currentMonth)/\(year1)"
            if Int(cell.datelabel.text!)!<10
            {
                 selectdate = "0\(cell.datelabel.text!)/\(currentMonth)/\(year1)"

            }
            
            let formate = DateFormatter()
            formate.dateFormat="dd/MMMM/yyyy"
            let date = formate.date(from: selectdate)
            formate.dateFormat="yyyy-MM-dd"
            let f_date = formate.string(from: date!)
            print(f_date)
            if global_vars.date_chk == 1
            {
                global_vars.start_date = f_date

            }
            if global_vars.date_chk == 2
            {
                global_vars.end_date = f_date
                
            }
            if global_vars.date_chk == 3
            {
                global_vars.R_cldr = f_date
                
            }
             selected_date.text = f_date
            
//            selected_date_fornote = selectdate
//            date_for_event_select = selectdate
//            let temp = datee()
//            temp.y = year1
//            temp.m = currentMonth
//            temp.d = Int(cell.datelabel.text!)!
//            abc.append(temp)
           // didselectcaldate = abc[indexPath.row]
        }
        collectionView.reloadData()
    }
    
    
    func iseventexist(m:String,y:Int,d:Int) -> Bool {
        for item in abc {
            if (d==item.d) && (m==item.m) && (y==item.y){
                return true
            }
        }
        return false
    }
    
    @IBAction func donebtn_pre(_ sender: Any) {
        
        if global_vars.cal_record_check == 2 {
            self.performSegue(withIdentifier: "back_to_r", sender: nil)

        }
        else
        {
            self.performSegue(withIdentifier: "back", sender: nil)
            
        }
    }
}

class datee {
    var y = 0
    var m = ""
    var d = 0
    init() {
        y = 0
        m = ""
        d = 0
    }
}
