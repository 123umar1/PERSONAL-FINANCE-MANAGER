
import UIKit
import SQLite3
class HomeViewController: UIViewController  , UICollectionViewDelegate,UICollectionViewDataSource , UITableViewDataSource,UITableViewDelegate{
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70
    }
    @IBOutlet weak var enddt: UILabel!
    @IBOutlet weak var startdt: UILabel!
    @IBOutlet weak var end_dt: UILabel!
    @IBOutlet weak var strt_dt: UILabel!
    
    @IBOutlet weak var menu_collection:    UICollectionView!
    
    @IBOutlet weak var lblincome: UILabel!
    @IBOutlet weak var tbalance: UILabel!
    
    @IBOutlet weak var txt_pwd: UITextField!
    
    @IBOutlet weak var lbl_epwd: UILabel!
    @IBOutlet weak var lbl_pwd: UILabel!
    
    @IBOutlet weak var btn_login: UIButton!
    @IBOutlet weak var home_tblview: UITableView!
    @IBOutlet weak var lblexpense: UILabel!
    var menu = ["HOME","SEARCH","RECORD","CATEGORIES","CHARTS","SETTINGS"]

    var income_arr = [income_cls]()
    var check : Int = 0
    var cell_ : Int = 0
    var dbb: OpaquePointer?
    var iamount = String()
    var eamount = String()
    var result : Int = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        prepareDatabaseFile()
        select_paswrd()
        select_expense()
        select_income()
        if global_vars.pwd_check == 1
        {
            lbl_pwd.isHidden = false
            lbl_epwd.isHidden = false
            txt_pwd.isHidden = false
            btn_login.isHidden = false
        }
        
        else
        {
            lbl_pwd.isHidden = true
            lbl_epwd.isHidden = true
            txt_pwd.isHidden = true
            btn_login.isHidden = true

        }
        
   let date1 = Date()
        let formate = DateFormatter()
        formate.dateFormat="yyyy-MM-dd"
        let date = formate.string(from: date1)
        print(date)
        
        if global_vars.i == 0 {
            global_vars.start_date = "2018-01-01"
            global_vars.end_date = date
            global_vars.i = 100
        }
        
         strt_dt.text = global_vars.start_date
        end_dt.text = global_vars.end_date

        home_tblview.isHidden = true
        
        select_notes()
        select()
        let c = Int(iamount)
        let b = Int(eamount)
        
        if c == nil || b == nil
        {
            print ("no record found")
            
        }
        else{
        result = c! - b!
        }
        tbalance.text = String(result)

    }
    @IBAction func btn_login(_ sender: Any) {
        let pwd = txt_pwd.text
        if global_vars.pwd == pwd {
            lbl_pwd.isHidden = true
            lbl_epwd.isHidden = true
            txt_pwd.isHidden = true
            btn_login.isHidden = true
        }
        else
        {
            print("Invalid Password")
        }
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return income_arr.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell : customTableViewCell = home_tblview.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! customTableViewCell
        cell.v_date.text = income_arr[indexPath.row].vdate
        cell.lbl_type.text = income_arr[indexPath.row].type
        cell.lbl_amount.text = income_arr[indexPath.row].amount
        
        if cell_ == 1 {
            cell.backgroundColor = UIColor.green
            
        }
        if cell_ == 2 {
            cell.backgroundColor = UIColor.red
            
        }
        
        return cell
    }
    
    
    func  prepareDatabaseFile()->String
    {
        let fileName: String = "Personal_finance2.db"
        let fileManager:FileManager=FileManager.default
        let directory=fileManager.urls(for: .documentDirectory, in: .userDomainMask).first!
        let documentUrl=directory.appendingPathComponent(fileName)
        // let bundleUrl=Bundle.main.resourceURL?.appendingPathComponent(fileName)
        let bundleUrl=Bundle.main.url(forResource: "Personal_finance2", withExtension: "db")
        //Bundle.main.resourceURL?.appendingPathComponent(fileName)
        
        print(bundleUrl?.path)
        print(documentUrl.path)
        
        if fileManager.fileExists(atPath: (documentUrl.path))
        {
            print("db already exists")
            let _ = openDatabase(path: documentUrl.path)
            return documentUrl.path
        }
            
        else if fileManager.fileExists(atPath: (bundleUrl?.path)!)
        {
            do{
                print("db missing, copying from bundle")
                try fileManager.copyItem(at: bundleUrl!, to: documentUrl)
            }catch{
                print("copy db error")
            }
        }
        return documentUrl.path
    }
    func openDatabase(path:String) -> OpaquePointer? {
        var db: OpaquePointer? = nil
        if sqlite3_open(path, &db) == SQLITE_OK {
            print("Successfully opened connection to database at \(path)")
            self.dbb = db
            //            print(dbb)
            //   select()
            return db
        } else {
            print("Unable to open database. Verify that you created the directory described " +
                "in the Getting Started section.")
            //            PlaygroundPage.current.finishExecution()
            return db
        }
        
    }
   func select_expense() {
        var queryStatement: OpaquePointer? = nil
        // 1
        let queryStatementString = "select category_subtype, Amount ,Date from Record where Category_type = 'Expense' ;"
        if sqlite3_prepare_v2(dbb, queryStatementString, -1, &queryStatement, nil) == SQLITE_OK {
            // 2
            while(sqlite3_step(queryStatement) == SQLITE_ROW){
                
                let top = income_cls()
                let queryResultCol1 = sqlite3_column_text(queryStatement, 0)
                let a = String(cString: queryResultCol1!)
                top.type = a

                let queryResultCol2 = sqlite3_column_text(queryStatement, 1)
                let b = String(cString: queryResultCol2!)
                top.amount = b
                
                let queryResultCol3 = sqlite3_column_text(queryStatement, 2)
                let c = String(cString: queryResultCol3!)
                top.vdate = c
                income_arr.append(top)
            }
            if sqlite3_step(queryStatement) == SQLITE_ROW {
                
            } else {
                print("Query returned no results")
            }
        } else {
            print("SELECT statement could not be prepared")
        }
        // 6
        sqlite3_finalize(queryStatement)
    }
    // password
    func select_paswrd() {
        var queryStatement: OpaquePointer? = nil
        // 1
        let queryStatementString = "select pwd , switch from password where id = (select  max(id) from password) ;"
        if sqlite3_prepare_v2(dbb, queryStatementString, -1, &queryStatement, nil) == SQLITE_OK {
            // 2
            while(sqlite3_step(queryStatement) == SQLITE_ROW){
                
                
                let queryResultCol1 = sqlite3_column_text(queryStatement, 0)
                let a = String(cString: queryResultCol1!)
                
                global_vars.pwd = a
                
                
                let queryResultCol2 = sqlite3_column_text(queryStatement, 1)
                let b = String(cString: queryResultCol2!)
                let pwd = Int(b)
                global_vars.pwd_check = pwd!
                
                
            }
            if sqlite3_step(queryStatement) == SQLITE_ROW {
                
            } else {
                print("Query returned no results")
            }
        } else {
            print("SELECT statement could not be prepared")
        }
        // 6
        sqlite3_finalize(queryStatement)
    }
    func select_income() {
        var queryStatement: OpaquePointer? = nil
        // 1
        let queryStatementString = "select category_subtype , Amount , Date  from Record where Category_type = 'Income' ;"
        if sqlite3_prepare_v2(dbb, queryStatementString, -1, &queryStatement, nil) == SQLITE_OK {
            // 2
            while(sqlite3_step(queryStatement) == SQLITE_ROW){
                
                let top = income_cls()
                
                let queryResultCol1 = sqlite3_column_text(queryStatement, 0)
                let a = String(cString: queryResultCol1!)
                top.type = a
                
                
                let queryResultCol2 = sqlite3_column_text(queryStatement, 1)
                let b = String(cString: queryResultCol2!)
                top.amount = b
                
                let queryResultCol3 = sqlite3_column_text(queryStatement, 2)
                let c = String(cString: queryResultCol3!)
                top.vdate = c
                
                income_arr.append(top)
                
                
            
            }
            if sqlite3_step(queryStatement) == SQLITE_ROW {
                
            } else {
                print("Query returned no results")
            }
        } else {
            print("SELECT statement could not be prepared")
        }
        // 6
        sqlite3_finalize(queryStatement)
        
    }
    func select_notes() {
        var queryStatement: OpaquePointer? = nil
        // 1
       
        let queryStatementString = "Select SUM (Amount) FROM Record where Category_type  = 'Income' and Date >= '\(global_vars.start_date!)' and Date <= '\(global_vars.end_date!)';"
        if sqlite3_prepare_v2(dbb, queryStatementString, -1, &queryStatement, nil) == SQLITE_OK {
            // 2
            while(sqlite3_step(queryStatement) == SQLITE_ROW){

                let queryResultCol1 = sqlite3_column_text(queryStatement, 0)
               if queryResultCol1 == nil
               {
                print("no record found")
               }
                else
               {
                let a = String(cString: queryResultCol1!)
                //  top.notes_date = viewnotes_date
                lblincome.text = a
                iamount = a ;
                
            }
            }
            if sqlite3_step(queryStatement) == SQLITE_ROW {
                
            } else {
                print("Query returned no results")
            }
        }
    else {
            print("SELECT statement could not be prepared")
        }
        // 6
        sqlite3_finalize(queryStatement)
    }
    func select() {
        var queryStatement: OpaquePointer? = nil
        // 1
        let queryStatementString = "Select SUM (Amount) FROM Record where Category_type = 'Expense'and Date >= '\(global_vars.start_date!)' and Date <= '\(global_vars.end_date!)';"
        if sqlite3_prepare_v2(dbb, queryStatementString, -1, &queryStatement, nil) == SQLITE_OK {
            // 2
            while(sqlite3_step(queryStatement) == SQLITE_ROW){
                
                let queryResultCol1 = sqlite3_column_text(queryStatement, 0)
                if queryResultCol1 == nil
                {
                    print("no record found")
                }
                else{
                let a = String(cString: queryResultCol1!)
                lblexpense.text = a
                eamount = a
            }
            }
            if sqlite3_step(queryStatement) == SQLITE_ROW {
                
            } else {
                print("Query returned no results")
            }
        } else {
            print("SELECT statement could not be prepared")
        }
        // 6
        sqlite3_finalize(queryStatement)
        
    }


    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return menu.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell : customCollectionViewCell = menu_collection.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! customCollectionViewCell
            cell.lblname.text = menu[indexPath.row]
        
            if cell.lblname.text == "HOME"
            {
                cell.lblbar.isHidden = false
            }
        else
            {
                cell.lblbar.isHidden = true

        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let name = menu[indexPath.row]
        
        if name == "SEARCH" {
            let secondVC  = storyboard?.instantiateViewController(withIdentifier: "searchViewController") as! searchViewController
            self.navigationController?.pushViewController(secondVC, animated: true)
        }
        if name == "RECORD" {
            let secondVC  = storyboard?.instantiateViewController(withIdentifier: "recordViewController") as! recordViewController
            self.navigationController?.pushViewController(secondVC, animated: true)
        }
        if name == "CATEGORIES" {
            let secondVC  = storyboard?.instantiateViewController(withIdentifier: "categoryViewController") as! CategoryViewController
            self.navigationController?.pushViewController(secondVC, animated: true)
        }        
        if name == "CHARTS" {
            let secondVC  = storyboard?.instantiateViewController(withIdentifier: "chartsViewController") as! ChartsViewController
            self.navigationController?.pushViewController(secondVC, animated: true)        }
        if name == "SETTINGS" {
            let secondVC  = storyboard?.instantiateViewController(withIdentifier: "settingsViewController") as! SettingsViewController
            self.navigationController?.pushViewController(secondVC, animated: true)        }
        }
    @IBAction func expense_detail(_ sender: Any) {
        
        cell_ = 2
        
        income_arr.removeAll()
        
        select_expense()
        check =  check + 1

        if check == 1 {
            home_tblview.reloadData()
            home_tblview.isHidden = false
            check = 2
        }
        if check == 3 {
            home_tblview.isHidden = true
            check =  0
        }
    }
    @IBAction func calendar_btn_1(_ sender: Any) {
    
        self.performSegue(withIdentifier: "cal", sender: nil)
        global_vars.date_chk = 1
        global_vars.cal_record_check = 4
    }
    @IBAction func calendar_btn_2(_ sender: Any) {
        self.performSegue(withIdentifier: "cal", sender: nil)
        global_vars.date_chk = 2
        global_vars.cal_record_check = 4
    }
    @IBAction func income_detail(_ sender: Any) {
        cell_ = 1
        income_arr.removeAll()
        
        select_income()

        check =  check + 1
        
        if check == 1 {
            home_tblview.reloadData()
            home_tblview.isHidden = false
            check = 2
        }
        if check == 3 {
            home_tblview.isHidden = true
            check =  0
        }
    }
}
class income_cls {
    
    var type = " "
    var amount = " "
    var vdate = " "
    init() {
     
        vdate = " "
        type = " "
        amount = " "
        
    }
    
}

