//
//  customTableViewCell.swift
//  Personal Finance Manager
//
//  Created by Umar  on 04/01/2019.
//  Copyright © 2019 Umar . All rights reserved.
import UIKit
class customTableViewCell: UITableViewCell {
    @IBOutlet weak var v_date: UILabel!
    @IBOutlet weak var lbl_type: UILabel!
    @IBOutlet weak var lbl_amount: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
