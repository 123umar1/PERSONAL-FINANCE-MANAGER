//
//  ChartCollectionViewCell.swift
//  Personal Finance Manager
//
//  Created by Umar  on 02/01/2019.
//  Copyright © 2019 Umar . All rights reserved.
//

import UIKit

class ChartCollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet weak var bar: UILabel!
    
    @IBOutlet weak var clr: UILabel!
    
}
