
import UIKit
import CoreCharts
import SQLite3

class ChartsViewController: UIViewController,CoreChartViewDataSource , UICollectionViewDataSource,UICollectionViewDelegate  {
    var dbb: OpaquePointer?
    var inc = String()
    var exp = String()
    var incc = Int()
    var expp = Int()
    var notes = String()
    var note = Int()
    var menu = ["HOME","SEARCH","RECORD","CATEGORIES","CHARTS","SETTINGS"]
    var chart_name = [String]()
    var chart_arr = [Int]()
    
    @IBOutlet weak var chartmenu: UICollectionView!
    override func viewDidLoad() {
        super.viewDidLoad()
        prepareDatabaseFile()
        select_income()
        chartmenu.reloadData()
        barChart.dataSource = self
    }
    func didTouch(entryData: CoreChartEntry) {
        print(entryData.barTitle)
    }
    
    func loadCoreChartData() -> [CoreChartEntry] {
        
        return getTurkeyFamouseCityList()
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return menu.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell : ChartCollectionViewCell = chartmenu.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! ChartCollectionViewCell
        cell.bar.text = menu[indexPath.row]
        
        if cell.bar.text == "CHARTS"
        {
            cell.clr.isHidden = false
        }
        else
        {
            cell.clr.isHidden = true
            
        }
        return cell
    }

    @IBOutlet weak var barChart: VCoreBarChart!
    
    func getTurkeyFamouseCityList()->[CoreChartEntry] {
        var allCityData = [CoreChartEntry]()
        print(chart_name)
        print(chart_arr)
        let cityNames = chart_name
        let plateNumber = chart_arr
        
        for index in 0..<cityNames.count {
            
            
            let newEntry = CoreChartEntry(id: "\(plateNumber[index])", barTitle: cityNames[index], barHeight: Double(plateNumber[index]), barColor: rainbowColor())
            
            allCityData.append(newEntry)
            
        }
        
        return allCityData
        
    }
    
    func  prepareDatabaseFile()->String
    {
        let fileName: String = "Personal_finance2.db"
        let fileManager:FileManager=FileManager.default
        let directory=fileManager.urls(for: .documentDirectory, in: .userDomainMask).first!
        let documentUrl=directory.appendingPathComponent(fileName)
        // let bundleUrl=Bundle.main.resourceURL?.appendingPathComponent(fileName)
        let bundleUrl=Bundle.main.url(forResource: "Personal_finance2", withExtension: "db")
        //Bundle.main.resourceURL?.appendingPathComponent(fileName)
        
        print(bundleUrl?.path)
        print(documentUrl.path)
        
        if fileManager.fileExists(atPath: (documentUrl.path))
        {
            print("db already exists")
            let _ = openDatabase(path: documentUrl.path)
            return documentUrl.path
        }
            
        else if fileManager.fileExists(atPath: (bundleUrl?.path)!)
        {
            do{
                print("db missing, copying from bundle")
                try fileManager.copyItem(at: bundleUrl!, to: documentUrl)
            }catch{
                print("copy db error")
            }
        }
        return documentUrl.path
    }
    func openDatabase(path:String) -> OpaquePointer? {
        var db: OpaquePointer? = nil
        if sqlite3_open(path, &db) == SQLITE_OK {
            print("Successfully opened connection to database at \(path)")
            self.dbb = db
            //            print(dbb)
            //   select()
            return db
        } else {
            print("Unable to open database. Verify that you created the directory described " +
                "in the Getting Started section.")
            //            PlaygroundPage.current.finishExecution()
            return db
        }
    }
    func select_income() {
        var queryStatement: OpaquePointer? = nil
        // 1
        
        let queryStatementString = "select SUM (Amount) from Record where Category_type = 'Income';"
        if sqlite3_prepare_v2(dbb, queryStatementString, -1, &queryStatement, nil) == SQLITE_OK {
            // 2
            while(sqlite3_step(queryStatement) == SQLITE_ROW){
                
                let queryResultCol1 = sqlite3_column_text(queryStatement, 0)
                if queryResultCol1 == nil
                {
                    print("no record found")
                }
                else
                {
                    let a = String(cString: queryResultCol1!)
                    
                    inc = a
                    print(inc)
                }
            }
            if sqlite3_step(queryStatement) == SQLITE_ROW {
                
            } else {
                print("Query returned no results")
            }
        }
        else {
            print("SELECT statement could not be prepared")
        }
        //
        sqlite3_finalize(queryStatement)
    }
    
    func select_expense() {
        var queryStatement: OpaquePointer? = nil
        // 1
        let queryStatementString = "select SUM (Amount) from Record where Category_subtype = 'Fuel';"
        if sqlite3_prepare_v2(dbb, queryStatementString, -1, &queryStatement, nil) == SQLITE_OK {
            // 2
            while(sqlite3_step(queryStatement) == SQLITE_ROW){
                
                let queryResultCol1 = sqlite3_column_text(queryStatement, 0)
                if queryResultCol1 == nil
                {
                    print("no record found")
                }
                else
                {
                    let a = String(cString: queryResultCol1!)
                    
                    exp = a
                    print(exp)
                }
            }
            if sqlite3_step(queryStatement) == SQLITE_ROW {
                
            } else {
                print("Query returned no results")
            }
        }
        else {
            print("SELECT statement could not be prepared")
        }
        // 6
        sqlite3_finalize(queryStatement)
    }
    
    
    func select_subtype() {
        var queryStatement: OpaquePointer? = nil
        // 1
        
        let queryStatementString = "select  Category_subtype, amount , Category_type from Record where Date > '2019-00-00'    ;"
        if sqlite3_prepare_v2(dbb, queryStatementString, -1, &queryStatement, nil) == SQLITE_OK {
            // 2
            while(sqlite3_step(queryStatement) == SQLITE_ROW){
                
                let queryResultCol1 = sqlite3_column_text(queryStatement, 0)
                if queryResultCol1 == nil
                {
                    print("no record found")
                }
                else
                {
                    let a = String(cString: queryResultCol1!)
                    
                    chart_name.append(a)
                  
                }
                let queryResultCol2 = sqlite3_column_text(queryStatement, 1)
                if queryResultCol2 == nil
                {
                    print("no record found")
                }
                else
                {
                    let b = String(cString: queryResultCol2!)
                    chart_arr.append(Int(b)!)
                    
                }
            }
            if sqlite3_step(queryStatement) == SQLITE_ROW {
                
            } else {
                print("Query returned no results")
            }
        }
        else {
            print("SELECT statement could not be prepared")
        }
        // 6
        sqlite3_finalize(queryStatement)
    }
    
    
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let name = menu[indexPath.row]
        
        if name == "HOME" {
            let secondVC  = storyboard?.instantiateViewController(withIdentifier: "homeViewController") as! HomeViewController
            self.navigationController?.pushViewController(secondVC, animated: true)
        }
        
        if name == "SEARCH" {
            let secondVC  = storyboard?.instantiateViewController(withIdentifier: "searchViewController") as! searchViewController
            self.navigationController?.pushViewController(secondVC, animated: true)
        }
        if name == "RECORD" {
            let secondVC  = storyboard?.instantiateViewController(withIdentifier: "recordViewController") as! recordViewController
            self.navigationController?.pushViewController(secondVC, animated: true)
        }
        if name == "CATEGORIES" {
            let secondVC  = storyboard?.instantiateViewController(withIdentifier: "categoryViewController") as! CategoryViewController
            self.navigationController?.pushViewController(secondVC, animated: true)
        }
        if name == "SETTINGS" {
            let secondVC  = storyboard?.instantiateViewController(withIdentifier: "chartsViewController") as! ChartsViewController
            self.navigationController?.pushViewController(secondVC, animated: true)        }
        
    }
 

}
