
//  Created by Umar  on 16/12/2018.
//  Copyright © 2018 Umar . All rights reserved.
//

import UIKit
import SQLite3

class CategoryViewController: UIViewController ,  UICollectionViewDataSource,UICollectionViewDelegate {
    var dbb: OpaquePointer?

    @IBOutlet weak var rdbtn1: DLRadioButton!
    @IBOutlet weak var collection_view: UICollectionView!
    @IBOutlet weak var lblname: UITextField!
    @IBOutlet weak var lblnotes: UITextField!
    var menu = ["HOME","SEARCH","RECORD","CATEGORIES","CHARTS","SETTINGS"]
    var type = String()
    var name = String()
    var notes = String()

    override func viewDidLoad() {
        super.viewDidLoad()
        prepareDatabaseFile()
        navigationItem.title = "CATEGORIES"
        collection_view.reloadData()
    }

    @IBAction func save_btn(_ sender: Any) {
        
        name = lblname.text!
        notes = lblnotes.text!
        //insert()
        inser_cat()
        showToast(message: "Category Added Successfully")
        lblname.text = ""
        lblnotes.text = ""
    }
    
    
    @IBAction func reset_btn(_ sender: Any) {
        
      lblname.text = ""
        lblnotes.text = ""
        
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return menu.count
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let name = menu[indexPath.row]
        
        if name == "HOME" {
            let secondVC  = storyboard?.instantiateViewController(withIdentifier: "homeViewController") as! HomeViewController
            self.navigationController?.pushViewController(secondVC, animated: true)
        }
        
        if name == "SEARCH" {
            let secondVC  = storyboard?.instantiateViewController(withIdentifier: "searchViewController") as! searchViewController
            self.navigationController?.pushViewController(secondVC, animated: true)
        }
        if name == "RECORD" {
            let secondVC  = storyboard?.instantiateViewController(withIdentifier: "recordViewController") as! recordViewController
            self.navigationController?.pushViewController(secondVC, animated: true)
        }
        if name == "CHARTS" {
            let secondVC  = storyboard?.instantiateViewController(withIdentifier: "chartsViewController") as! ChartsViewController
            self.navigationController?.pushViewController(secondVC, animated: true)        };
        if name == "SETTINGS" {
            let secondVC  = storyboard?.instantiateViewController(withIdentifier: "settingsViewController") as! SettingsViewController
            self.navigationController?.pushViewController(secondVC, animated: true)        }
   
    
    }
    
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell : CategoryCollectionViewCell = collection_view.dequeueReusableCell(withReuseIdentifier: "cell2", for: indexPath) as! CategoryCollectionViewCell
        cell.lblname.text = menu[indexPath.row]
        if cell.lblname.text == "CATEGORIES"
        {
            cell.lblname.isHidden = false
        }
        else
        {
            cell.lblclr.isHidden = true
            
        }
        return cell
    }
    
    
    @IBAction func btn_click(_ sender: DLRadioButton) {
        if sender.tag == 1
        {
            
            print("income")
            type = "Income"
            
        }
        if sender.tag == 2
        {
            print("Expense")
            type = "Expense"
        }
        
        
    }
    func insert() {
        
        let insertStatementString = "INSERT INTO Categories (category_type, category_name, category_notes) VALUES (?, ?, ?);"
        var insertStatement: OpaquePointer? = nil
        
        // 1
        if sqlite3_prepare_v2(dbb, insertStatementString, -1, &insertStatement, nil) == SQLITE_OK {
            
            let c_type: NSString = type as NSString
            let c_name: NSString = lblname?.text?.trimmingCharacters(in: .whitespacesAndNewlines) as! NSString
            let c_notes: NSString = lblnotes?.text?.trimmingCharacters(in: .whitespacesAndNewlines) as! NSString

            
            print(c_type)
            print(c_name)
            print(c_notes)
            // 2
            sqlite3_bind_text(insertStatement, 1, c_type.utf8String, -1, nil)
            sqlite3_bind_text(insertStatement, 2, c_name.utf8String, -1, nil)
            sqlite3_bind_text(insertStatement, 3, c_notes.utf8String, -1, nil)
            
            
            if sqlite3_step(insertStatement) == SQLITE_DONE {
                print("Successfully inserted row.")
            } else {
                print("Could not insert row.")
            }
        } else {
            print("INSERT statement could not be prepared.")
        }
        // 5
        sqlite3_finalize(insertStatement)
    }

    
    func inser_cat()  {
        let insertStatementString = "INSERT INTO Categories (category_type, category_name, category_notes) VALUES (?, ?, ?);"
        var insertStatement: OpaquePointer? = nil
// 1
        if sqlite3_prepare_v2(dbb, insertStatementString, -1, &insertStatement, nil) == SQLITE_OK {
            
            let c_type: NSString = type as NSString
            let c_name: NSString = lblname?.text?.trimmingCharacters(in: .whitespacesAndNewlines) as! NSString
            let c_notes: NSString = lblnotes?.text?.trimmingCharacters(in: .whitespacesAndNewlines) as! NSString
            
            
            print(c_type)
            print(c_name)
            print(c_notes)
            // 2
            sqlite3_bind_text(insertStatement, 1, c_type.utf8String, -1, nil)
            sqlite3_bind_text(insertStatement, 2, c_name.utf8String, -1, nil)
            sqlite3_bind_text(insertStatement, 3, c_notes.utf8String, -1, nil)
            
            if sqlite3_step(insertStatement) == SQLITE_DONE {
                print("Successfully inserted row.")
            } else {
                print("Could not insert row.")
            }
        } else {
            print("INSERT statement could not be prepared.")
        }
        // 5
        sqlite3_finalize(insertStatement)
    }
    
    
    //connect db
    
    func  prepareDatabaseFile()->String
    {
        let fileName: String = "Personal_finance2.db"
        let fileManager:FileManager=FileManager.default
        let directory=fileManager.urls(for: .documentDirectory, in: .userDomainMask).first!
        let documentUrl=directory.appendingPathComponent(fileName)
        // let bundleUrl=Bundle.main.resourceURL?.appendingPathComponent(fileName)
        let bundleUrl=Bundle.main.url(forResource: "Personal_finance2", withExtension: "db")
        //Bundle.main.resourceURL?.appendingPathComponent(fileName)
        
        print(bundleUrl?.path)
        print(documentUrl.path)
        
        if fileManager.fileExists(atPath: (documentUrl.path))
        {
            print("db already exists")
            let _ = openDatabase(path: documentUrl.path)
            return documentUrl.path
        }
            
        else if fileManager.fileExists(atPath: (bundleUrl?.path)!)
        {
            do{
                print("db missing, copying from bundle")
                try fileManager.copyItem(at: bundleUrl!, to: documentUrl)
            }catch{
                print("copy db error")
            }
        }
        return documentUrl.path
    }
    
    func openDatabase(path:String) -> OpaquePointer? {
        var db: OpaquePointer? = nil
        if sqlite3_open(path, &db) == SQLITE_OK {
            print("Successfully opened connection to database at \(path)")
            self.dbb = db
            //            print(dbb)
            //   select()
            return db
        } else {
            print("Unable to open database. Verify that you created the directory described " +
                "in the Getting Started section.")
            //            PlaygroundPage.current.finishExecution()
            return db
        }
        
    }
    
}
