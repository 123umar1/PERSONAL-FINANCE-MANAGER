//
//  CategoryCollectionViewCell.swift
//  Personal Finance Manager
//
//  Created by Umar  on 14/12/2018.
//  Copyright © 2018 Umar . All rights reserved.
//

import UIKit

class CategoryCollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet weak var lblname: UILabel!
        @IBOutlet weak var lblclr: UILabel!
}
