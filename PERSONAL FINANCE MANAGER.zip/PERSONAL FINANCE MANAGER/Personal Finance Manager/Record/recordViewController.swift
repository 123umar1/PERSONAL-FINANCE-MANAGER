//
//  recordViewController.swift
//  Personal Finance Manager
//
//  Created by Umar  on 09/12/2018.
//  Copyright © 2018 Umar . All rights reserved.
import UIKit
import SQLite3

class recordViewController: UIViewController ,UICollectionViewDataSource,UICollectionViewDelegate,UITableViewDelegate,UITableViewDataSource{
    var dbb: OpaquePointer?
 var a : Int = 0
    var weekly = String()
    var monthly = String()
    var yearly = String()
    var category_type = String()
    var category_subtype = String()
    var recurr = String()
    var amount = String()
    var Notes = String()
    var notes_date=" "
    var recour_notes = " "
    var cat_notes = ""
    var cat_check = String()
    @IBOutlet weak var txtshort_notes: UITextField!
    @IBOutlet weak var clndr: UIButton!
    @IBOutlet weak var btn1: DLRadioButton!
    @IBOutlet weak var rdbtn2: UIButton!
    @IBOutlet weak var rdbtn1: UIButton!
    @IBOutlet weak var txtamount: UITextField!
    @IBOutlet weak var btncheck: UIButton!
    var check : Int = 0
    @IBOutlet weak var btn_cat: UIButton!
    @IBOutlet weak var btn_duration: UIButton!
    @IBOutlet weak var tbl_view: UITableView!
    @IBOutlet weak var lbldate: UILabel!
    @IBOutlet weak var menu_collection: UICollectionView!
    @IBOutlet weak var btn: UIButton!
    var freq = ["Weekly","Monthly","Yearly"]
    var sal = [String]()// catagories
    var duration = ["4","8","12","16","20","24","28","30"]
    var menu = ["HOME","SEARCH","RECORD","CATEGORIES","CHARTS","SETTINGS"]
    
    var arr1 = ["4","8","12","16","20","24","28","32","36","40","44","48"]
    var arr2 = ["12","24","36","48","60","72","84","96"]
    var arr3 = ["2","3","4","5","6","7","8","9","10"]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        prepareDatabaseFile()
        
        btn_duration.isHidden = true
        btn_cat.isHidden = true
        menu_collection.reloadData()
        self.tbl_view.isHidden = true
        lbldate.text = "00/00/0000";
        check = 0
        
        if global_vars.cal_record_check == 0 {
            let date0 = Date()
            let formate = DateFormatter()
            formate.dateFormat="yyyy-MM-dd"
            let a = formate.string(from: date0)
            
            lbldate.text = a
            
        }
       else
        {
            lbldate.text = global_vars.R_cldr
        }
    }
    @IBAction func celendar3(_ sender: Any) {
            self.performSegue(withIdentifier: "t_celendar", sender: nil)
            global_vars.date_chk = 3
            global_vars.cal_record_check = 2
    }
    //insert data
    func insert() {
        notes_date = lbldate.text!
//        recour_notes = "yes"
//        cat_notes = "salary"
        amount = txtamount.text!
        let insertStatementString = "INSERT INTO Record (Date, Category_type, Category_subtype , Recurring , Amount, Notes) VALUES (? , ? , ? , ? , ? , ?);"
        var insertStatement: OpaquePointer? = nil
        if sqlite3_prepare_v2(dbb, insertStatementString, -1, &insertStatement, nil) == SQLITE_OK {
            let a : NSString = notes_date as NSString
            let category_t: NSString = category_type as NSString
            let category_st: NSString = category_subtype as NSString
            let reoccur_: NSString =  recurr as NSString
            let amount1: NSString = txtamount.text?.trimmingCharacters(in: .whitespacesAndNewlines) as! NSString
            let short_notes : NSString = txtshort_notes?.text?.trimmingCharacters(in: .whitespacesAndNewlines)as!NSString
          
            // 2
            sqlite3_bind_text(insertStatement, 1,  a.utf8String, -1 , nil)
            sqlite3_bind_text(insertStatement, 2, category_t.utf8String, -1, nil)
            sqlite3_bind_text(insertStatement, 3, category_st.utf8String, -1, nil)
            sqlite3_bind_text(insertStatement, 4, reoccur_.utf8String, -1, nil)
            sqlite3_bind_text(insertStatement, 5, amount1.utf8String, -1, nil)
            sqlite3_bind_text(insertStatement, 6, short_notes.utf8String, -1, nil)
            
            if sqlite3_step(insertStatement) == SQLITE_DONE {
                print("Successfully inserted row.")
            } else {
                print("Could not insert row.")
            }
        } else {
            print("INSERT statement could not be prepared.")
        }
        sqlite3_finalize(insertStatement)
    }
    @IBAction func btnradio_click(_ sender: DLRadioButton) {
        if sender.tag == 1 {
            print("Income")
            sal.removeAll()
            //func income
            select_income()
            category_type = "Income"
        }
        if sender.tag == 2 {
            sal.removeAll()
            //expense
            select_expense()
            category_type = "Expense"
        }
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if check == 0 {
            return freq.count

        }
        
        if check == 1 {
            return freq.count

        }
        
        if check == 2 {
            return sal.count
            
        }
        
        if check == 4 {
            return arr2.count
            
        }
        if check == 5 {
            return arr1.count
            
        }
        if check == 6 {
            return arr3.count
            
        }
        
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell : UITableViewCell = tbl_view.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        if check == 0 {
            cell.textLabel?.text = freq[indexPath.row]
            }
        if check == 1 {
            cell.textLabel?.text = freq[indexPath.row]
        }
        
        
        if check == 2 {
            cell.textLabel?.text = sal[indexPath.row]
            
        }
        if check == 3 {
            cell.textLabel?.text = duration[indexPath.row]
            
        }
       
        if check == 4 {
            cell.textLabel?.text = arr2[indexPath.row]
            
        }
        if check == 5 {
            cell.textLabel?.text = arr1[indexPath.row]
        }
        if check == 6 {
            cell.textLabel?.text = arr3[indexPath.row]
            
        }
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cell = tbl_view.cellForRow(at: indexPath)
        
        if check == 1 {
            btn_cat.setTitle(cell?.textLabel?.text, for: .normal)
            category_subtype = (cell?.textLabel?.text)!
            
            cat_check = (cell?.textLabel?.text!)!
                if cat_check == "Monthly"
                {
                     check = 4
                        
                }
                if cat_check == "Weekly"
                {
                      check = 5
                
                }
                if cat_check == "Yearly"
                {
                     check = 6
                
                }
            }
     
        if check == 2 {
            btn.setTitle(cell?.textLabel?.text, for: .normal)
            category_subtype = (cell?.textLabel?.text)!
        }
        
//        if check == 3 {
//            btn_duration.setTitle(cell?.textLabel?.text, for: .normal)
//        }
        if check == 4 {
            btn_duration.setTitle(cell?.textLabel?.text, for: .normal)
            category_subtype = (cell?.textLabel?.text)!
        }
        if check == 5 {
            btn_duration.setTitle(cell?.textLabel?.text, for: .normal)
            category_subtype = (cell?.textLabel?.text)!
        }
        if check == 6 {
            btn_duration.setTitle(cell?.textLabel?.text, for: .normal)
            category_subtype = (cell?.textLabel?.text)!
        }
        self.tbl_view.isHidden = true
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return menu.count
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let name = menu[indexPath.row]
        
        if name == "HOME" {
            let secondVC  = storyboard?.instantiateViewController(withIdentifier: "homeViewController") as! HomeViewController
            self.navigationController?.pushViewController(secondVC, animated: true)
        }
        if name == "SEARCH" {
            let secondVC  = storyboard?.instantiateViewController(withIdentifier: "searchViewController") as! searchViewController
            self.navigationController?.pushViewController(secondVC, animated: true)
        }
        if name == "CATEGORIES" {
            let secondVC  = storyboard?.instantiateViewController(withIdentifier: "categoryViewController") as! CategoryViewController
            self.navigationController?.pushViewController(secondVC, animated: true)
        }
        
        if name == "CHARTS" {
            let secondVC  = storyboard?.instantiateViewController(withIdentifier: "chartsViewController") as! ChartsViewController
            self.navigationController?.pushViewController(secondVC, animated: true)        }
        if name == "SETTINGS" {
            let secondVC  = storyboard?.instantiateViewController(withIdentifier: "settingsViewController") as! SettingsViewController
            self.navigationController?.pushViewController(secondVC, animated: true)        }
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell : recordCollectionViewCell = menu_collection.dequeueReusableCell(withReuseIdentifier: "cell1", for: indexPath) as! recordCollectionViewCell
            cell.lblname.text = menu[indexPath.row]
        if cell.lblname.text == "RECORD"
        {
            cell.lbl1.isHidden = false
        }
        else
        {
            cell.lbl1.isHidden = true

        }
            return cell
    }
    
    
    //catagoty button
    
    
    @IBAction func btn_click(_ sender: Any) {
        check = 1
        self.tbl_view.isHidden = !self.tbl_view.isHidden
        self.tbl_view.reloadData()

    }
    
    
    @IBAction func btn_duration_clicked(_ sender: Any) {
        if cat_check == "Monthly" {
            check = 4
            self.tbl_view.isHidden = !self.tbl_view.isHidden
            self.tbl_view.reloadData()
            btn_duration.setTitle("12", for: .normal)
        }
        
        if cat_check == "Weekly" {
            check = 5
            self.tbl_view.isHidden = !self.tbl_view.isHidden
            self.tbl_view.reloadData()
            btn_duration.setTitle("4", for: .normal)

        }
        if cat_check == "Yearly" {
            check = 6
            self.tbl_view.isHidden = !self.tbl_view.isHidden
            self.tbl_view.reloadData()
            btn_duration.setTitle("2", for: .normal)

        }
    }
    
    @IBAction func btn_cat(_ sender: Any) {
        check = 2
        self.tbl_view.isHidden = !self.tbl_view.isHidden
        self.tbl_view.reloadData()
    }
    
    
    @IBAction func btncheck(_ sender: Any) {
        if a==0 {
            btn_cat.isHidden = false
            btn_duration.isHidden = false
            let img1 = UIImage(named: "checked.png")
            btncheck.setImage(img1, for: .normal)
            a = 1
            recurr = "yes"
            
        }
        else if a==1
        {
            btn_cat.isHidden = true
            btn_duration.isHidden = true
            let img1 = UIImage(named: "unchecked.png")
            btncheck.setImage(img1, for: .normal)
            a = 0
            recurr = "No"
        }
        
    }
    
    @IBAction func savebtn_clicked(_ sender: Any) {

        insert()
        showToast(message: "Record Saved")
        txtamount.text = ""
        txtshort_notes.text = ""
        btn_cat.isHidden = true
        btn_duration.isHidden = true
        //btncheck.isHidden = true
        let img1 = UIImage(named: "unchecked.png")
        btncheck.setImage(img1, for: .normal)
    }
    //connect db
    func  prepareDatabaseFile()->String
    {
        let fileName: String = "Personal_finance2.db"
        let fileManager:FileManager=FileManager.default
        let directory=fileManager.urls(for: .documentDirectory, in: .userDomainMask).first!
        let documentUrl=directory.appendingPathComponent(fileName)
        // let bundleUrl=Bundle.main.resourceURL?.appendingPathComponent(fileName)
        let bundleUrl=Bundle.main.url(forResource: "Personal_finance2", withExtension: "db")
        //Bundle.main.resourceURL?.appendingPathComponent(fileName)
        
        print(bundleUrl?.path)
        print(documentUrl.path)
        
        if fileManager.fileExists(atPath: (documentUrl.path))
        {
            print("db already exists")
            let _ = openDatabase(path: documentUrl.path)
            return documentUrl.path
        }
            
        else if fileManager.fileExists(atPath: (bundleUrl?.path)!)
        {
            do{
                print("db missing, copying from bundle")
                try fileManager.copyItem(at: bundleUrl!, to: documentUrl)
            }catch{
                print("copy db error")
            }
        }
        return documentUrl.path
    }
    
    func openDatabase(path:String) -> OpaquePointer? {
        var db: OpaquePointer? = nil
        if sqlite3_open(path, &db) == SQLITE_OK {
            print("Successfully opened connection to database at \(path)")
            self.dbb = db
            //  print(dbb)
            // select()
            return db
        } else {
            print("Unable to open database. Verify that you created the directory described " +
                "in the Getting Started section.")
            //            PlaygroundPage.current.finishExecution()
            return db
        }
    }
    func select_income() {
        var queryStatement: OpaquePointer? = nil
        // 1
        let queryStatementString = "Select category_name from Categories where category_type = 'Income' ;"
        if sqlite3_prepare_v2(dbb, queryStatementString, -1, &queryStatement, nil) == SQLITE_OK {
            // 2
            while(sqlite3_step(queryStatement) == SQLITE_ROW){
                
                let queryResultCol1 = sqlite3_column_text(queryStatement, 0)
                let a = String(cString: queryResultCol1!)
                sal.append(a)
                
            }
            if sqlite3_step(queryStatement) == SQLITE_ROW {
                
            } else {
                print("Query returned no results")
            }
        } else {
            print("SELECT statement could not be prepared")
        }
        // 6
        sqlite3_finalize(queryStatement)
    }
    
    
    func select_expense() {
        var queryStatement: OpaquePointer? = nil
        // 1
        let queryStatementString = "Select category_name from Categories where category_type = 'Expense' ;"
        if sqlite3_prepare_v2(dbb, queryStatementString, -1, &queryStatement, nil) == SQLITE_OK {
            // 2
            while(sqlite3_step(queryStatement) == SQLITE_ROW){
                
                let queryResultCol1 = sqlite3_column_text(queryStatement, 0)
                let a = String(cString: queryResultCol1!)
                sal.append(a)
                
            }
            if sqlite3_step(queryStatement) == SQLITE_ROW {
                
            } else {
                print("Query returned no results")
            }
        } else {
            print("SELECT statement could not be prepared")
        }
        // 6
        sqlite3_finalize(queryStatement)
        
    }
    
    @IBAction func reset_btn_click(_ sender: Any) {
        txtamount.text = ""
        txtshort_notes.text = ""
        btn_cat.isHidden = true
        btn_duration.isHidden = true
        //btncheck.isHidden = true
        let img1 = UIImage(named: "unchecked.png")
        btncheck.setImage(img1, for: .normal)
    }
}
