//
//  recordCollectionViewCell.swift
//  Personal Finance Manager
//
//  Created by Umar  on 10/12/2018.
//  Copyright © 2018 Umar . All rights reserved.
//

import UIKit

class recordCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var lblname: UILabel!
    @IBOutlet weak var lbl1: UILabel!
}
