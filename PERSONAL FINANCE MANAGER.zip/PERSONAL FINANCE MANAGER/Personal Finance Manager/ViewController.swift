//
//  ViewController.swift
//  Personal Finance Manager
//
//  Created by Umar  on 09/12/2018.
//  Copyright © 2018 Umar . All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

