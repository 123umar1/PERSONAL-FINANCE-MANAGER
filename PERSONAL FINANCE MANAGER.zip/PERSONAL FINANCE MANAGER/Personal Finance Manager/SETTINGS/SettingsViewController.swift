//
//  SettingsViewController.swift
//  Personal Finance Manager
//
//  Created by Umar  on 06/01/2019.
//  Copyright © 2019 Umar . All rights reserved.
import UIKit
import SQLite3

class SettingsViewController: UIViewController ,UICollectionViewDelegate,UICollectionViewDataSource   {
    
    
    
    @IBOutlet weak var menu_collection: UICollectionView!
    @IBOutlet weak var txt_pwd: UITextField!
    @IBOutlet weak var txt_c_pwd: UITextField!
    @IBOutlet weak var myswitch: UISwitch!
    
    var pwd = ""
    var on_off : Int = 0
    
    var menu = ["HOME","SEARCH","RECORD","CATEGORIES","CHARTS","SETTINGS"]

    var dbb: OpaquePointer?
    override func viewDidLoad()
    {
        super.viewDidLoad()
        prepareDatabaseFile()
        
        if global_vars.pwd_check == 1 {
            myswitch.setOn(true, animated: true)
        }
        else
        {
            myswitch.setOn(false, animated: true)

        }
        navigationItem.title = "SETTINGS"
        menu_collection.reloadData()

        txt_pwd.isHidden = true
        txt_c_pwd.isHidden = true
        
        
    }
    
    
    @IBAction func switch_(_ sender: UISwitch) {
        if sender.isOn {
            txt_pwd.isHidden = false
            txt_c_pwd.isHidden = false
            on_off = 1
            
        }
        else
        {
            txt_pwd.isHidden = true
            txt_c_pwd.isHidden = true
            on_off = 0
            update()
        }
    }
    
    @IBAction func btn_setpasswrd(_ sender: Any) {
        
        let a = txt_pwd.text
        let b = txt_c_pwd.text
        
        
        if a == b {
            insert()

        }
        else
        {
            showToast(message: "Not matched")
            
        }
    }
    func update() {
    
    let insertStatementString = "UPDATE password set switch = 0 WHERE id = (SELECT MAX(id) FROM password);"
    var insertStatement: OpaquePointer? = nil
    
    if sqlite3_prepare_v2(dbb, insertStatementString, -1, &insertStatement, nil) == SQLITE_OK {
    
    if sqlite3_step(insertStatement) == SQLITE_DONE {
    print("Successfully updated row.")
    } else {
    print("Could not update row.")
    }
    } else {
    print("update statement could not be prepared.")
    }
    // 5
    sqlite3_finalize(insertStatement)
}
    func insert() {
       
        pwd = txt_pwd.text!
        let insertStatementString = "INSERT INTO password (pwd, switch) VALUES (? , ? );"
        var insertStatement: OpaquePointer? = nil
        
        if sqlite3_prepare_v2(dbb, insertStatementString, -1, &insertStatement, nil) == SQLITE_OK {
            
          
            let pswrd: NSString = txt_pwd.text?.trimmingCharacters(in: .whitespacesAndNewlines) as! NSString
             let switch_: Int = on_off
            global_vars.pwd_check = on_off
            // 2
            sqlite3_bind_text(insertStatement, 1,  pswrd.utf8String, -1 , nil)
            sqlite3_bind_int(insertStatement, 2, Int32(switch_))
            
            if sqlite3_step(insertStatement) == SQLITE_DONE {
                print("Successfully inserted row.")
            } else {
                print("Could not insert row.")
            }
        } else {
            print("INSERT statement could not be prepared.")
        }
        // 5
        sqlite3_finalize(insertStatement)
    }
  
    func  prepareDatabaseFile()->String
    {
        let fileName: String = "Personal_finance2.db"
        let fileManager:FileManager=FileManager.default
        let directory=fileManager.urls(for: .documentDirectory, in: .userDomainMask).first!
        let documentUrl=directory.appendingPathComponent(fileName)
        // let bundleUrl=Bundle.main.resourceURL?.appendingPathComponent(fileName)
        let bundleUrl=Bundle.main.url(forResource: "Personal_finance2", withExtension: "db")
        //Bundle.main.resourceURL?.appendingPathComponent(fileName)
        
        print(bundleUrl?.path)
        print(documentUrl.path)
        
        if fileManager.fileExists(atPath: (documentUrl.path))
        {
            print("db already exists")
            let _ = openDatabase(path: documentUrl.path)
            return documentUrl.path
        }
            
        else if fileManager.fileExists(atPath: (bundleUrl?.path)!)
        {
            do{
                print("db missing, copying from bundle")
                try fileManager.copyItem(at: bundleUrl!, to: documentUrl)
            }catch{
                print("copy db error")
            }
        }
        return documentUrl.path
    }
    func openDatabase(path:String) -> OpaquePointer? {
        var db: OpaquePointer? = nil
        if sqlite3_open(path, &db) == SQLITE_OK {
            print("Successfully opened connection to database at \(path)")
            self.dbb = db
            //            print(dbb)
            //   select()
            return db
        } else {
            print("Unable to open database. Verify that you created the directory described " +
                "in the Getting Started section.")
            //            PlaygroundPage.current.finishExecution()
            return db
        }
        
    }
    
   
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return menu.count
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let name = menu[indexPath.row]
        
        if name == "HOME" {
            let secondVC  = storyboard?.instantiateViewController(withIdentifier: "homeViewController") as! HomeViewController
            self.navigationController?.pushViewController(secondVC, animated: true)
        }
        
        if name == "SEARCH" {
            let secondVC  = storyboard?.instantiateViewController(withIdentifier: "searchViewController") as! searchViewController
            self.navigationController?.pushViewController(secondVC, animated: true)
        }
        if name == "RECORD" {
            let secondVC  = storyboard?.instantiateViewController(withIdentifier: "recordViewController") as! recordViewController
            self.navigationController?.pushViewController(secondVC, animated: true)
        }
        if name == "CATEGORIES" {
            let secondVC  = storyboard?.instantiateViewController(withIdentifier: "categoryViewController") as! CategoryViewController
            self.navigationController?.pushViewController(secondVC, animated: true)
        }
        if name == "CHARTS" {
            let secondVC  = storyboard?.instantiateViewController(withIdentifier: "chartsViewController") as! ChartsViewController
            self.navigationController?.pushViewController(secondVC, animated: true)        }
     
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell : SettingsCollectionViewCell = menu_collection.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! SettingsCollectionViewCell
        cell.Bar.text = menu[indexPath.row]
        
        if cell.Bar.text == "SETTINGS"
        {
            cell.Clr.isHidden = false
        }
        else
        {
            cell.Clr.isHidden = true
            
        }
        return cell
    }
    
}


