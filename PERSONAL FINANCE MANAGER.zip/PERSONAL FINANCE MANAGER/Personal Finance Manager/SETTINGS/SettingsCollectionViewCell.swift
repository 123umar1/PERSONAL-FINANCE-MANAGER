//
//  SettingsCollectionViewCell.swift
//  Personal Finance Manager
//
//  Created by Umar  on 06/01/2019.
//  Copyright © 2019 Umar . All rights reserved.
//

import UIKit

class SettingsCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var Bar: UILabel!
    @IBOutlet weak var Clr: UILabel!
    
    
    
}
