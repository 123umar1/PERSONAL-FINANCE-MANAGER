//
//  Category_CollectionViewCell.swift
//  New_p_finance
//
//  Created by Umar  on 27/12/2018.
//  Copyright © 2018 Umar . All rights reserved.
//

import UIKit

class Category_CollectionViewCell: UICollectionViewCell {
  
    @IBOutlet weak var bar: UILabel!
    @IBOutlet weak var clr: UILabel!
    
    
}
