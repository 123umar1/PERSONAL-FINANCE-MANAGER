//
//  Record_ViewController.swift
//  New_p_finance
//
//  Created by Umar  on 27/12/2018.
//  Copyright © 2018 Umar . All rights reserved.
//

import UIKit
import SQLite3

class Record_ViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource ,UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        <#code#>
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        <#code#>
    }
    
 
    
  
    @IBAction func btn(_ sender: Any) {
    }
    @IBOutlet weak var tblview: UITableView!
    @IBOutlet weak var txt: UITextField!
    @IBOutlet weak var c_view: UICollectionView!
    
    var array = [String]()
    
    
    var menu = ["Home","Categries","Record","Search","Chart","Settings"]
    override func viewDidLoad() {
        super.viewDidLoad()
 
       tblview.delegate = self
        tblview.dataSource = self
        
        
        array.append("one")
        array.append("two")
        array.append("three")
        
        


        
        
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return menu.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell : Record_CollectionViewCell = c_view.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! Record_CollectionViewCell
        cell.bar.text = menu[indexPath.row]
        if cell.bar.text == "Record"
        {
            cell.clr.isHidden = false
        }
        else
        {
            cell.clr.isHidden = true
            
        }
        return cell
    }

}
