//
//  ViewController.swift
//  New_p_finance
//
//  Created by Umar  on 27/12/2018.
//  Copyright © 2018 Umar . All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

