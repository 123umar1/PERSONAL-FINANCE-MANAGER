//
//  calendarVars.swift
//  new calendar
//
//  Created by Umar  on 12/01/2019.
//  Copyright © 2019 Umar . All rights reserved.
//
import Foundation
let date1 = Date()
let calendar = Calendar.current
let day1 = calendar.component(.day, from: date1)
let weekday1 = calendar.component(.weekday, from: date1)
var month1 = calendar.component(.month, from: date1) - 1
var year1 = calendar.component(.year, from: date1)
