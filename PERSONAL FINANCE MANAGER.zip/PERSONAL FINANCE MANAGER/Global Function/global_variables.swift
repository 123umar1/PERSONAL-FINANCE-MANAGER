//
//  global_variables.swift
//  Personal Finance Manager
//  Created by Umar  on 22/12/2018.
//  Copyright © 2018 Umar . All rights reserved.
import Foundation
struct global_vars
{
    static var R_cldr : String?
    static var dbb: OpaquePointer?
    static var start_date : String?
     static var date_chk : Int?
    static var end_date : String?
    static var i : Int = 0
    static var cal_record_check : Int = 0
    static var pwd_check : Int?
    static var pwd : String?

}
