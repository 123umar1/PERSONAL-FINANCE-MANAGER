//
//  dateCollectionViewCell.swift
//  new calendar
//
//  Created by Umar  on 12/01/2019.
//  Copyright © 2019 Umar . All rights reserved.
import UIKit

class dateCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var datelabel: UILabel!
}
